from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from api import views

urlpatterns =[
    path('api/',views.PeopleDataList.as_view()),
    path('api/<int:pk>/',views.PeopleDataDetail.as_view()),
    path('api/list/',views.ApiView.as_view()),
]

urlpatterns=format_suffix_patterns(urlpatterns)