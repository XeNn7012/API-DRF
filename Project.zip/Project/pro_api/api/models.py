from django.db import models

class People_Data(models.Model):
    first_name = models.CharField(max_length=200,blank=True)
    last_name = models.CharField(max_length=200,blank=True)
    company_name = models.CharField(max_length=200,blank=True)
    city = models.CharField(max_length=200,blank=True)
    state = models.CharField(max_length=200,blank=True)
    zip=models.IntegerField(blank=True)
    email = models.EmailField(max_length=200,blank=True)
    web=models.CharField(max_length=200,blank=True)
    age=models.IntegerField(blank=True)
     
