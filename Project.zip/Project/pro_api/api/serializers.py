from rest_framework import serializers
from api.models import People_Data

class People_Data_serializers(serializers.ModelSerializer):
    class Meta:
        model=People_Data
        fields='__all__'       
