from api.models import People_Data
from api.serializers import People_Data_serializers
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.generics import ListAPIView
from rest_framework.pagination import PageNumberPagination
from rest_framework import filters
from rest_framework.filters import OrderingFilter

class PeopleDataList(APIView):
    def get(self, request, format=None):
        peoplesData = People_Data.objects.all()
        serializer=People_Data_serializers(peoplesData,many=True)
        return Response(serializer.data)
    
    def post(self, request, format=None):
        serializer=People_Data_serializers(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

class PeopleDataDetail(APIView):
    def get_object(self,pk):
        try:
            return People_Data.objects.get(pk=pk)
        except People_Data.DoesNotExist:
            raise Http404
        
    def get(self, request,pk,format=None):
        people_data=self.get_object(pk)
        serializer=People_Data_serializers(people_data)
        return Response(serializer.data)
    
    def put(self, request, pk, format=None):
        people_data = self.get_object(pk)
        serializer = People_Data_serializers(people_data, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request,pk,format=None):
        people_data=self.get_object(pk)
        people_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class ApiView(ListAPIView):
    queryset = People_Data.objects.all()
    serializer_class = People_Data_serializers
    pagination_class=PageNumberPagination
    filter_backends = [filters.SearchFilter,OrderingFilter,]
    search_fields = ['^first_name', '^last_name']










































# from api.models import People_Data
# from api.serializers import People_Data_serializers
# from django.http import Http404
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from rest_framework.generics import ListAPIView
# from rest_framework.pagination import PageNumberPagination

# class PeopleDataList(APIView):
#     def get(self,request, format=None):
#         peoplesData = People_Data.objects.all()
#         serializer=People_Data_serializers(peoplesData,many=True)
#         return Response(serializer.data)
    
#     def post(self, request, format=None):
#         serializer=People_Data_serializers(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data,status=status.HTTP_201_CREATED)
#         return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

# class PeopleDataDetail(APIView):
#     def get_object(self,request,pk):
#         try:
#             return People_Data.objects.get(pk=pk)
#         except People_Data.DoesNotExist:
#             raise Http404
        
#     def get(self,pk,request,format=None):
#         people_data=self.get_object(pk)
#         serializer=People_Data_serializers(people_data)
#         return Response(serializer.data)
    
#     def put(self, request,pk,format=None):
#         people_data=self.get_object(pk)
#         serializer=People_Data_serializers(people_data,data=request.data)
#         if serializer.is_valid:
#             serializer.save()
#             return Response(serializer.data,status=status.HTTP_201_CREATED)
#         return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
    
#     def delete(self,pk,request,format=None):
#         people_data=self.get_object(pk)
#         people_data.delete()
#         return Response(status=status.HTTP_204_NO_CONTENT)

# # class ApiView(ListAPIView):
# #     queryset = People_Data.objects.all()
# #     serializer = People_Data_serializers
# #     pagination=PageNumberPagination
